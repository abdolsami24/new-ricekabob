MADINAH MARKET - HOMEPAGE HERO PHOTO + VIDEO UPDATE
====================================================
The homepage hero is now independent from dish #13 (Sultani Kabob),
and it can also play a short video.

WHAT IT DOES
- Admin -> Operations now has a "Homepage hero" card with two rows:
  * Hero photo: upload a photo used ONLY for the homepage hero.
    Until one is uploaded, the hero keeps using the Sultani Kabob
    photo, exactly as today. "Remove hero photo" (shown when a custom
    photo is set) restores the Sultani photo.
  * Hero video: upload a short MP4 or WebM. When a video is set, it
    plays on the homepage (muted, on a loop) instead of the photo,
    with the hero photo as its poster. Keep it short - under about
    15 seconds / 10 MB (server accepts up to 15 MB).
    "Remove hero video" restores the photo.
- The hero photo/video are stored in the same dish_photos table and
  dish-photos bucket as dish photos, under reserved ids (__hero__ and
  __hero_video__). They never appear as dishes anywhere.
- GIF is now also accepted for photo uploads (it is treated as an
  image).

UPLOAD (GitHub repo abdolsami24/madinah-market) - ONE FOLDER AT A TIME:
1. Extract this ZIP first (do not upload from inside the ZIP window).
2. Upload the lib folder file:        lib/admin.ts
3. Upload the app folder files:       app/page.tsx
                                      app/api/admin/route.ts
4. Upload the components folder file: components/AdminPanel.tsx
5. Wait for Vercel to finish deploying (about 1-2 minutes).
   (An intermediate deploy may show an error until all folders are in;
   that is normal - it goes green after the last folder.)

NO SQL is needed. No database changes.

AFTER DEPLOY: go to Admin -> Operations -> "Homepage hero" and upload
a hero photo (and a hero video if you have one).
